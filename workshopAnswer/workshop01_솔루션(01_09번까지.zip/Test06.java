public class Test06 {

	public static void main(String[] args) {
		int i = 5;
		String result = (i % 2 == 0) ? "짝수" : "홀수";
		System.out.println("숫자 " + i + "은(는) " + result + " 입니다.");
	}
}
